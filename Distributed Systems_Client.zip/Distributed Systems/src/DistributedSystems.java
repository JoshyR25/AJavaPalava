import java.rmi.Remote;
import java.rmi.RemoteException;

/* 
 * A remote interface extends the interface 
 * java.rmi.Remote and declares a set of remote
 * methods. Each method must declare an exception
 * (java.rmi.RemoteException)
 *
 * No implementation goes here--only the
 * interface definition.
 * 
 */
public interface DistributedSystems extends Remote {
	String printHello() throws RemoteException;
       // String printXmas() throws RemoteException;
}
