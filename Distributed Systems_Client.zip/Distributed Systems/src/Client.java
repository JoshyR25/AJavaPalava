import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;

public class Client {
    /* Give the host where the RMI registry is 
     *  running as a command line argument
     */
    public static void main(String[] args) {
		
	//if(args.length != 1) {
	    //System.out.println("You must provide a command line");
	    //System.out.println("argument specifying where the");
	    System.out.println("registry is running"); 
	    //System.exit(-1);
	//}
	
       
        //String host = args[0];
        String host = "192.168.0.168";
	
        try {
	    Registry registry = 
		LocateRegistry.getRegistry(host);
	    DistributedSystems stub = 
		(DistributedSystems) registry.lookup("CNET343HelloWorld");
            
	    /* Next line is the remote method invocation */
	    String response = stub.printHello();
            //String response2 = stub.printXmas();
	    System.out.println("Response: " + response);
           // System.out.println("Josh " + response2);
	} catch (Exception e) {
	    System.err.println("Client exception: " + 
			       e.toString());
	    e.printStackTrace();
	}
    }
}
